# Starter less-based template 

Includes:
* Bootstrap grid, forms and responsive utilities 
* CSS3Pie http://css3pie.com
* backgroundsize https://github.com/louisremi/background-size-polyfill