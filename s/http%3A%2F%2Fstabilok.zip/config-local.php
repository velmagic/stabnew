<?php

$SITE_ID = 5250;
$AFF_ID = 8688;

?>
