<?php
// deze file is in het nederlands dag naam, maand naam en jaar.
// this file contains the Dutch weekday names, month names and suffixes.
// fix provided by Paul Font Freide, additional fix provided by BuStEl.

$days = array ('zondag','maandag', 'dinsdag', 'woensdag','donderdag', 'vrijdag', 'zaterdag');
$daysabbr = array();
$months = array ('januari', 'februari', 'maart', 'april', 'mei', 'juni','juli',
'augustus', 'september', 'oktober', 'november', 'december');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
'','','','','','','','','');

?> 