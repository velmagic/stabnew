<?php
// this file contains the English weekday names, month names and suffixes.

$days   = array ('Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi');
$daysabbr = array();
$months = array ('janvier','f�vrier','mars','avril','mai','juin','juillet','ao�t',
                 'septembre','octobre','novembre','d�cembre');
$suffixes = array ('er','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>