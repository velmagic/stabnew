<?php
// this file contains the English weekday names, month names and suffixes.

$days   = array ('Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
$daysabbr = array();
$months = array ('January','February','March','April','May','June','July','August',
                 'September','October','November','December');
$suffixes = array ('st','nd','rd','th','th','th','th','th','th','th','th','th','th','th',
                   'th','th','th','th','th','th','st','nd','rd','th','th','th','th','th',
                   'th','th','st');
?>