<?php
// this file contains the Danish weekday names, month names and suffixes.

$days   = array ('s�ndag','mandag', 'tirsdag', 'onsdag','torsdag', 'fredag', 'l�rdag');
$daysabbr = array();
$months = array ('januar', 'februar', 'marts', 'april', 'maj', 'juni','juli',
                 'august', 'september', 'oktober', 'november', 'december');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>