<?php
// this file contains the Spanish weekday names, month names and suffixes.

$days   = array ('Domingo','Lunes', 'Martes', 'Mi�rcoles', 'Jueves', 'Viernes', 'S�bado');
$daysabbr = array();
$months = array ('enero','febrero','marzo','abril','mayo','junio','julio','agosto',
                 'septiembre','octubre','noviembre','noviembre');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>