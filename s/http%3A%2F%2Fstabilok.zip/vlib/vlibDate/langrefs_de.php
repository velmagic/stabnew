<?php
// this file contains the German weekday names, month names and suffixes.

$days   = array ('Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag');
$daysabbr = array();
$months = array ('Januar','Februar','M�rz','April','Mai','Juni','Juli','August',
                 'September','Oktober','November','Dezember');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>