<?php
// this file contains the Finnish weekday names, month names and suffixes.

$days   = array ('sunnuntai','maanantai', 'tiistai', 'keskiviikko','torstai', 'perjantai', 'lauantai');
$daysabbr = array();
$months = array ('tammikuu', 'helmikuu', 'maaliskuu', 'huhtikuu','toukokuu', 'kes�kuu',
                 'hein�kuu', 'elokuu','syyskuu', 'lokakuu', 'marraskuu', 'joulukuu');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>