<?php
// this file contains the Romanian weekday names, month names and suffixes.
// traslated by Stefan Isarie -> stefanis@gmx.net

$days   = array ('Duminica','Luni','Marti','Miercuri','Joi','Vineri','Sambata');
$daysabbr = array();
$months = array ('Ianuarie','Februarie','Martie','Aprilie','Mai','Iunie','Iulie','August',
                 'Septembrie','Octombrie','Noiembrie','Decembrie');
$suffixes = array ('','','','','','','','','','','','','','',
                   '','','','','','','','','','','','','','',
                   '','','');
?>