<?php
// this file contains the Portugues weekday names, month names and suffixes.

$days   = array ('Domingo','Segunda-feira', 'Ter�a-feira', 'Quarta-feira','Quinta-feira', 'Sexta-feira', 'S�bado');
$daysabbr = array("Dom","2�","3�","4�","5�","6�","S�b");
$months = array ('janeiro', 'fevereiro', 'mar�o', 'abril', 'maio', 'junho','julho',
                 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>