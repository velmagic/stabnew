<?php
// this file contains the Norwegian weekday names, month names and suffixes.

$days   = array ('s�ndag','mandag', 'tirsdag', 'onsdag','torsdag', 'fredag', 'l�rdag');
$daysabbr = array();
$months = array ('januar', 'februar', 'mars', 'april', 'mai', 'juni','juli',
                 'august', 'september', 'oktober', 'november', 'desember');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>