<?php
// this file contains the Swedish weekday names, month names and suffixes.

$days   = array ('s�ndag','m�ndag', 'tisdag', 'onsdag', 'torsdag', 'fredag', 'l�rdag');
$daysabbr = array();
$months = array ('januari', 'februari', 'mars', 'april', 'maj', 'juni','juli',
                 'augusti', 'september', 'oktober', 'november', 'december');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>