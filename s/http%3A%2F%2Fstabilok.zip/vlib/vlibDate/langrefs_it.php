<?php
// this file contains the Italian weekday names, month names and suffixes.

$days   = array ('Domenica','Luned�','Marted�','Mercoled�','Gioved�','Venerd�','Sabato');
$daysabbr = array();
$months = array ('Gennaio', 'Febbraio', 'Marzo', 'Aprile', 'Maggio', 'Giugno', 'Luglio',
                 'Agosto', 'Settembre', 'Ottobre', 'Novembre', 'Dicembre');
$suffixes = array ('','','','','','','','','','','','','','','','','','','','','','',
                   '','','','','','','','','');
?>